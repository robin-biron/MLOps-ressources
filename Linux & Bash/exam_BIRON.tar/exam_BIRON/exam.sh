
#!/bin/bash

# stockage des différentes références de carte graphique dans un tableau
cartes[0]='rtx3060'
cartes[1]='rtx3070'
cartes[2]='rtx3080'
cartes[3]='rtx3090' 
cartes[4]='rx6700'


# stockage des différentes valeurs des ventes correspondantes dans un tableau
ventes[0]=`curl "http://0.0.0.0:5000/rtx3060"`
ventes[1]=`curl "http://0.0.0.0:5000/rtx3070"`
ventes[2]=`curl "http://0.0.0.0:5000/rtx3080"`
ventes[3]=`curl "http://0.0.0.0:5000/rtx3090"`
ventes[4]=`curl "http://0.0.0.0:5000/rx6700"`

# get length of an array
arraylength=${#ventes[@]}

# create scrapping function
function scrapping {

echo `date`
for i in {0..4}
do
echo ${cartes[i]}:${ventes[i]}
done
} 

   
#call the function
scrapping >> ~/exam_BIRON/sales.txt
